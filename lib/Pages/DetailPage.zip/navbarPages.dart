import 'package:flutter/material.dart';

class NavbarPages extends StatelessWidget implements PreferredSizeWidget {
  final String formattedDate;

  const NavbarPages(this.formattedDate);

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Color.fromRGBO(63, 210, 199, 0.99),
      title: Text('Login'),
      actions: <Widget>[
        Container(
          width: 100,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
          ),
          padding: EdgeInsets.all(8),
          margin: EdgeInsets.all(8),
          child: Text(
            formattedDate,
            style: TextStyle(color: Colors.black),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
}
