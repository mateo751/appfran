import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


import 'DetailPage2.dart';
import 'navbarPages.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _password = '';
  String _formattedDate = DateFormat('hh:mm a').format(DateTime.now());

  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(Duration(minutes: 1), (Timer t) => _getTime());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _getTime() {
    final String formattedDateTime =
        DateFormat('hh:mm a').format(DateTime.now()).toString();
    setState(() {
      _formattedDate = formattedDateTime;
    });
  }

  void _login() {
    if (_formKey.currentState != null) {
      _formKey.currentState!.save();

      // Obtener la hora actual
      DateTime now = DateTime.now();

      // Definir las horas de inicio y fin
      DateTime start = DateTime(now.year, now.month, now.day, 8); // 7 AM
      DateTime end = DateTime(now.year, now.month, now.day, 24); // 7 PM

      // Comprobar si la hora actual está en el rango permitido
      if (now.isAfter(start) && now.isBefore(end)) {
        if (_email == 'admin' && _password == '123') {
          print('Acceso exitoso');
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => DetailPageTwo()),
          );
        } else {
          print('Credenciales incorrectas');
        }
      } else {
        print('No puedes iniciar sesión a esta hora. Por favor, intenta de nuevo entre las 7 AM y las 7 PM.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NavbarPages(_formattedDate),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Text('Menú'),
              decoration: BoxDecoration(
                color: Color.fromRGBO(63, 210, 199, 0.99),
              ),
            ),
            ListTile(
              title: Text('Opción 1'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Opción 2'),
              onTap: () {},
            ),
          ],
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Libreta Electrónica',
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'M003: Izobamba',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'Jorge Benalcazar',
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30.0),
                Text(
                  'Ingresar',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10.0),
                Form(
                  key: _formKey,
                  child: Column(
                    children: <Widget>[
                      TextFormField(
                        decoration: InputDecoration(labelText: 'Email'),
                        onSaved: (value) => _email = value ?? "",
                      ),
                      TextFormField(
                        decoration: InputDecoration(labelText: 'Clave'),
                        obscureText: true,
                        onSaved: (value) => _password = value ?? "",
                      ),
                      SizedBox(height: 10.0),
                      TextButton(
                        style: TextButton.styleFrom(
                          primary: Colors.blue,
                        ),
                        child: Text('Forgot your password'),
                        onPressed: () {},
                      ),
                      SizedBox(height: 20.0),
                      Container(
                        width: 200,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Colors.lightBlue,
                            onPrimary: Colors.white,
                          ),
                          child: Text('Sign In'),
                          onPressed: _login,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
